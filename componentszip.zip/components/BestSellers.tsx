import React, { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import AnimatedTitle from './ui/AnimatedTitle';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const FALLBACK_IMAGE = "https://images.unsplash.com/photo-1597481499750-3e6b22637e12?q=80&w=800&auto=format&fit=crop";

const products = [
  { name: "Saffron Turmeric Tea", price: "$24.00" },
  { name: "English Breakfast", price: "$18.00" },
  { name: "Mountain Honey", price: "$32.00" },
  { name: "Garam Masala Powder", price: "$15.00" }
];

const BestSellers: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top 60%", // Centered viewport trigger
          once: true
        }
      });

      // Reveal Cards
      tl.fromTo(".product-card", 
        { y: 50, opacity: 0, scale: 0.95 },
        { 
          y: 0, 
          opacity: 1, 
          scale: 1,
          stagger: 0.15, 
          duration: 1.2, 
          ease: "power3.out"
        }
      );
    }, containerRef);
    return () => ctx.revert();
  }, []);

  const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    gsap.to(target, { y: -5, duration: 0.4, ease: "power2.out" });
    gsap.to(target.querySelector('.prod-img'), { scale: 1.1, opacity: 1, duration: 0.6, ease: "power2.out" });
    gsap.to(target.querySelector('.quick-add-btn'), { y: 0, opacity: 1, duration: 0.4 });
    gsap.to(target.querySelector('.prod-border'), { borderColor: '#C5A059', opacity: 0.5, duration: 0.4 });
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    gsap.to(target, { y: 0, duration: 0.4, ease: "power2.out" });
    gsap.to(target.querySelector('.prod-img'), { scale: 1.0, opacity: 0.9, duration: 0.6, ease: "power2.out" });
    gsap.to(target.querySelector('.quick-add-btn'), { y: 15, opacity: 0, duration: 0.4 });
    gsap.to(target.querySelector('.prod-border'), { borderColor: 'rgba(255,255,255,0.05)', opacity: 1, duration: 0.4 });
  };

  const handleBtnClick = (e: React.MouseEvent<HTMLButtonElement>) => {
     e.stopPropagation();
     gsap.to(e.currentTarget, { scale: 0.9, yoyo: true, repeat: 1, duration: 0.1 });
  };

  return (
    <section ref={containerRef} className="py-32 bg-sublime-dark relative">
      <div className="container mx-auto px-6">
        <AnimatedTitle 
          title="Best Sellers" 
          subtitle="Customer Favorites"
          containerClass="mb-20"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {products.map((product, index) => (
            <div 
                key={index} 
                className="product-card group cursor-pointer opacity-0 will-change-transform"
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
            >
              {/* Product Image (Pill Shape) */}
              <div className="prod-border relative w-full aspect-[3/4] rounded-t-full rounded-b-full overflow-hidden mb-8 border border-white/5 bg-[#0a1510] transition-colors">
                <img 
                  src={FALLBACK_IMAGE}
                  onError={(e) => { e.currentTarget.src = FALLBACK_IMAGE; }}
                  alt={product.name} 
                  className="prod-img w-full h-full object-cover opacity-90 transition-none"
                />
                
                {/* Quick Add Overlay */}
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button 
                        onClick={handleBtnClick}
                        className="quick-add-btn translate-y-4 opacity-0 px-6 py-3 bg-sublime-gold text-sublime-dark text-xs font-bold uppercase tracking-widest rounded-full shadow-lg hover:bg-white transition-colors duration-300"
                    >
                        Quick Add
                    </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="text-center space-y-2">
                <h3 className="font-serif text-xl text-sublime-light group-hover:text-sublime-gold transition-colors duration-300">{product.name}</h3>
                <p className="font-sans text-sm text-white/50 tracking-wider">{product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellers;