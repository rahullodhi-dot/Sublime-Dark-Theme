import React, { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const partners = [
  "Sheraton Grand", "Bare Necessities", "Marriott", "Nature's Basket", "Taj Bangalore", "First Club"
];

const Partners: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
        const tl = gsap.timeline({
            scrollTrigger: {
                trigger: containerRef.current,
                start: "top 80%", 
                once: true
            }
        });

        // Reveal Logos
        tl.fromTo(".partner-logo",
            { opacity: 0, y: 30, scale: 0.95 },
            { 
                opacity: 0.6, 
                y: 0, 
                scale: 1,
                duration: 1.0, 
                stagger: 0.1, 
                ease: "power3.out"
            }
        );
    }, containerRef);
    return () => ctx.revert();
  }, []);

  const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
    gsap.to(e.currentTarget, { 
        scale: 1.05, 
        y: -4,
        opacity: 1,
        borderColor: 'rgba(197, 160, 89, 0.5)',
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        color: '#C5A059',
        duration: 0.3, 
        ease: "power2.out" 
    });
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    gsap.to(e.currentTarget, { 
        scale: 1, 
        y: 0,
        opacity: 0.6,
        borderColor: 'rgba(255, 255, 255, 0.1)',
        backgroundColor: 'transparent',
        color: 'rgba(255,255,255, 0.6)',
        duration: 0.3, 
        ease: "power2.out" 
    });
  };

  return (
    <section ref={containerRef} className="py-24 bg-sublime-dark border-t border-white/5">
      <div className="container mx-auto px-6 text-center">
        <p className="text-sublime-gold text-xs tracking-[0.2em] uppercase mb-12 opacity-80">Trust We Gain</p>
        
        <div className="flex flex-wrap justify-center gap-8 md:gap-16">
          {partners.map((partner, i) => (
            <div 
                key={i} 
                className="partner-logo opacity-0 h-20 w-32 md:w-48 border border-white/10 flex items-center justify-center text-center p-4 transition-all duration-500 cursor-default rounded-lg will-change-transform"
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
            >
               <span className="font-serif text-sm md:text-base text-white/60 transition-colors pointer-events-none">{partner}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Partners;