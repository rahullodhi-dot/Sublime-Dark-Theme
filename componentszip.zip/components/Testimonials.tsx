import React, { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { Star } from 'lucide-react';
import AnimatedTitle from './ui/AnimatedTitle';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const FALLBACK_AVATAR = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop";

const reviews = [
  {
    name: "Anita Sharma",
    location: "Bengaluru",
    text: "Sublime Signature Black Tea is pure perfection! The aroma is refreshing, the taste is soothing, and it instantly uplifts my mood.",
    image: "https://randomuser.me/api/portraits/women/12.jpg",
    title: "Exceptional Quality"
  },
  {
    name: "Vaibhav Vedsav",
    location: "Kolkata",
    text: "Our whole family loves Sublime Moroccan Mint Tea! It's refreshing, natural, and packed with antioxidants.",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    title: "Rich Aroma With Taste"
  },
  {
    name: "Paola Sebastian",
    location: "Mumbai",
    text: "Sublime Dry Fruits are pure perfection! The aroma is refreshing, the taste is soothing, and it instantly uplifts my mood.",
    image: "https://randomuser.me/api/portraits/women/65.jpg",
    title: "Exceptional Support"
  }
];

const Testimonials: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top 60%", // Centered viewport trigger
          once: true
        }
      });

      // Reveal Cards
      tl.fromTo(".review-card", 
        { y: 50, opacity: 0, scale: 0.95 },
        { 
          y: 0, 
          opacity: 1, 
          scale: 1,
          stagger: 0.2, 
          duration: 1.2, 
          ease: "power3.out"
        }
      );
    }, containerRef);
    return () => ctx.revert();
  }, []);

  const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
    gsap.to(e.currentTarget, { y: -5, borderColor: 'rgba(197, 160, 89, 0.4)', backgroundColor: 'rgba(255, 255, 255, 0.05)', duration: 0.4, ease: "power2.out" });
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    gsap.to(e.currentTarget, { y: 0, borderColor: 'rgba(255, 255, 255, 0.05)', backgroundColor: 'rgba(255, 255, 255, 0.03)', duration: 0.4, ease: "power2.out" });
  };

  return (
    <section ref={containerRef} className="py-32 bg-sublime-dark relative border-t border-white/5">
      <div className="container mx-auto px-6">
        <AnimatedTitle 
          title="Customer Stories" 
          subtitle="Trusted by Many"
          containerClass="mb-24"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {reviews.map((review, index) => (
            <div 
              key={index} 
              className="review-card opacity-0 bg-white/[0.03] border border-white/5 p-10 rounded-3xl relative text-center transition-all duration-500 group will-change-transform"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              
              <div className="absolute -top-10 left-1/2 transform -translate-x-1/2">
                <div className="w-20 h-20 rounded-full border border-sublime-gold/50 overflow-hidden shadow-2xl p-1 bg-sublime-dark group-hover:scale-110 transition-transform duration-500">
                  <img 
                    src={review.image} 
                    onError={(e) => { e.currentTarget.src = FALLBACK_AVATAR; }}
                    alt={review.name} 
                    className="w-full h-full rounded-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500" 
                  />
                </div>
              </div>

              <div className="mt-10 mb-6 flex justify-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={14} className="fill-sublime-gold text-sublime-gold opacity-90" />
                ))}
              </div>

              <h4 className="font-serif text-xl mb-6 text-sublime-light group-hover:text-sublime-gold transition-colors duration-300">{review.title}</h4>
              
              <p className="font-sans text-sm leading-7 text-white/60 mb-8 italic font-light">
                "{review.text}"
              </p>

              <div className="text-xs uppercase tracking-widest text-sublime-gold/80 font-bold">
                {review.name}
                <span className="block text-[9px] text-white/30 mt-1 font-normal tracking-wide">{review.location}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;