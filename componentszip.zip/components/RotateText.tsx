import React from "react"

type RotatedLuxuryTextProps = {
  text?: string
  side?: "left" | "right"
  position?: string
  className?: string
}

const RotatedLuxuryText: React.FC<RotatedLuxuryTextProps> = ({
  text = "TASTE OF LUXURY",
  side = "right",
  position = "right-20",
  className = "",
}) => {
  const sideClasses =
    side === "right"
      ? `
          ${position}
          top-1/2
          -translate-y-full
          origin-right
          rotate-90
        `
      : `
          ${position}
          top-[100%]
          translate-y-full
          origin-left
          -rotate-90
        `

  return (
    <div
      className={`
        absolute
        ${sideClasses}
        w-[840px]
        h-[135px]
        flex items-center
        z-[50]
        ${className}
      `}
    >
      <h2
        className="
          w-full
          text-center
          text-[#E8B8791A]
          font-bold
          tracking-[0.18rem]
          font-abril-fatface
          text-[100px]
          leading-none
          whitespace-nowrap
        "
      >
        {text}
      </h2>
    </div>
  )
}

export default RotatedLuxuryText
