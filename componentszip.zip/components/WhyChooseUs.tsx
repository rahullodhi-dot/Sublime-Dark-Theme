import React, { useRef, useLayoutEffect, useState, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Leaf, Package, Globe, User } from 'lucide-react';
import AnimatedTitle from './ui/AnimatedTitle';
import whyChooseUsBg from '../assests/WhyChooseUs.jpg';


gsap.registerPlugin(ScrollTrigger);

const features = [
  { icon: Leaf, title: 'Wellness Enhancing', desc: 'Curated to elevate body, mind, and spirit.' },
  { icon: Globe, title: 'Direct from Growers', desc: 'Authentic sourcing directly from the origin.' },
  { icon: Package, title: 'Sourced Fresh', desc: 'Small batches ensuring unmatched quality.' },
  { icon: User, title: 'Women Led', desc: 'Built on passion, purpose, and perseverance.' }
];

const WhyChooseUs: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgContainerRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const [points, setpoints] = useState<any[]>([]);



  useEffect(() => {
    const path = pathRef.current;
    const svgContainer = svgContainerRef.current;
    if (!path || !svgContainer) return;

    const pathLength = path.getTotalLength();
    console.log("pathLength", pathLength);
    const containerRect = svgContainer.getBoundingClientRect();
    const newPoints = [
      { label: "Discover", at: 0 },
      { label: "Design", at: 400 },
      { label: "Develop", at: 800 },
      { label: "Test", at: 1200 },

    ].map(step => {
      const point = path.getPointAtLength(step.at);

      return {
        ...step,
        x: (point.x / 1600) * containerRect.width,
        y: (point.y / 389) * containerRect.height
      };
    });

    setpoints(newPoints);

  }, [])

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top 60%", // Centered viewport trigger
          once: true
        }
      });

      // 1. Reveal Grid Items
      tl.fromTo(".feature-item",
        { y: 40, opacity: 0, scale: 0.95 },
        { y: 0, opacity: 1, scale: 1, duration: 1.0, stagger: 0.15, ease: "power3.out" }
      );

      // 2. Animate Vertical Dividers
      tl.fromTo(".grid-divider",
        { scaleY: 0, opacity: 0, transformOrigin: "top" },
        { scaleY: 1, opacity: 1, duration: 1.2, stagger: 0.1, ease: "expo.out" },
        0.5 // Overlap
      );

    }, containerRef);
    return () => ctx.revert();
  }, []);

  const handleMouseEnter = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    gsap.to(target, { y: -5, duration: 0.4, ease: "power2.out" });
    gsap.to(target.querySelector('.icon-wrapper'), { scale: 1.1, borderColor: '#C5A059', duration: 0.4 });
    gsap.to(target.querySelector('.icon-svg'), { color: '#C5A059', duration: 0.4 });
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    gsap.to(target, { y: 0, duration: 0.4, ease: "power2.out" });
    gsap.to(target.querySelector('.icon-wrapper'), { scale: 1, borderColor: 'rgba(255,255,255,0.1)', duration: 0.4 });
    gsap.to(target.querySelector('.icon-svg'), { color: '#EBE7E0', duration: 0.4 });
  };


  console.log("points", points);

  return (
    <section ref={containerRef} className="py-32 min-h-screen bg-sublime-dark relative overflow-hidden">
      <div className={`absolute inset-0 bg-bottom object-contain pointer-events-none mix-blend-overlay `}>
        <img src={whyChooseUsBg} alt="" className="w-full h-full object-cover" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedTitle
          title="Why Choose Us"
          subtitle="AWESOME PRODUCTS"
          containerClass="mb-20"
          text="#E8B879"
        />

        <div className="relative h-full w-full border-t border-b border-white/20">
          <div ref={svgContainerRef} className="border relative border-red-500 h-[20vw] w-full ">
            <svg className="mx-auto" xmlns="http://www.w3.org/2000/svg" width="900" height="389" viewBox="0 0 973 389" fill="none">
              <path
                ref={pathRef}
                pathLength="900"
                d="M0.0449 379.253 C192.229 387.988 126.058 2.746 331.999 2.746 C509.549 2.746 468.275 387.988 652.597 387.988 C863.704 387.988 777.953 0.999 972.321 0.999"
                stroke="#E8B879"
                strokeWidth="2"
                strokeDasharray="6 6"
                fill="none"
              />
            </svg>

            {
              points?.length > 0 && points.map((point, index) => (
                <div
                  key={index}
                  className="absolute bg-sublime-dark/80 backdrop-blur-md px-3 py-1 border border-red-500 rounded-full text-sm font-medium whitespace-nowrap shadow-lg"
                  style={{ left: point.x - 40, top: point.y - 20 }}
                >
                  {point.label}
                </div>
              ))
            }

          </div>

        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;