import React, { useRef, useLayoutEffect } from 'react';
import { Facebook, Instagram, Twitter } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Footer: React.FC = () => {
    const footerRef = useRef<HTMLDivElement>(null);

    useLayoutEffect(() => {
        const ctx = gsap.context(() => {
            const tl = gsap.timeline({
                scrollTrigger: {
                    trigger: footerRef.current,
                    start: "top 75%", // Ensure it triggers when mostly visible
                    once: true
                }
            });

            // Newsletter Reveal
            tl.fromTo(".newsletter-section", 
                { y: 40, opacity: 0 },
                {
                    y: 0,
                    opacity: 1,
                    duration: 1.2,
                    ease: "power3.out"
                }
            );

            // Footer Columns Reveal
            tl.fromTo(".footer-col", 
                { y: 30, opacity: 0 },
                {
                    y: 0,
                    opacity: 1,
                    duration: 1.0,
                    stagger: 0.1,
                    ease: "power3.out"
                },
                0.2
            );

        }, footerRef);
        return () => ctx.revert();
    }, []);

  return (
    <footer ref={footerRef} className="bg-sublime-dark pt-24 pb-10 border-t border-white/10 text-sublime-light relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-full bg-sublime-gold/5 blur-[100px] pointer-events-none"></div>

      <div className="container mx-auto px-6 relative z-10">
        
        {/* Newsletter Section */}
        <div className="newsletter-section text-center max-w-2xl mx-auto mb-20 opacity-0 will-change-transform">
          <h3 className="font-serif text-3xl md:text-5xl mb-6 text-sublime-light tracking-wide">Subscribe To Our Newsletter</h3>
          <p className="text-white/60 text-sm mb-10 font-light tracking-widest uppercase">For More Updates.</p>
          <div className="flex flex-col sm:flex-row gap-4">
            <input 
              type="email" 
              placeholder="Your Email Address" 
              className="flex-1 bg-white/5 border border-white/10 rounded-full px-8 py-4 text-sm focus:outline-none focus:border-sublime-gold transition-colors placeholder:text-white/30 text-white"
            />
            <button className="px-10 py-4 bg-transparent border border-sublime-gold text-sublime-gold rounded-full text-xs uppercase tracking-widest hover:bg-sublime-gold hover:text-sublime-dark transition-all duration-300">
              Subscribe
            </button>
          </div>
        </div>

        {/* Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16 border-b border-white/10 pb-16">
          <div className="footer-col opacity-0 will-change-transform text-center md:text-left">
             <div className="flex flex-col items-center md:items-start mb-6">
               <span className="font-serif text-2xl text-white">Sublime</span>
               <span className="text-[0.5rem] text-sublime-gold tracking-[0.3em] uppercase mt-1">Inspiring Awe</span>
             </div>
             <p className="text-xs text-white/50 leading-relaxed max-w-xs mx-auto md:mx-0 font-light">
               Sublime House of Tea is more than just a cup of tea, a jar of honey, or a spice. Founded in 2013, Sublime is in an attempt to bring freshness, superior quality, and authenticity to our daily lives.
             </p>
          </div>

          <div className="footer-col opacity-0 will-change-transform">
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-8">Discover</h4>
            <ul className="space-y-4 text-xs text-white/60 font-light">
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">FAQ</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">About Us</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Disclaimer</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Blog</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Contact Us</a></li>
            </ul>
          </div>

          <div className="footer-col opacity-0 will-change-transform">
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-8">Help Center</h4>
            <ul className="space-y-4 text-xs text-white/60 font-light">
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Return & Refund</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Privacy & Policy</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Terms Of Service</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Brochure</a></li>
              <li><a href="#" className="hover:text-sublime-gold transition-colors block">Track Order</a></li>
            </ul>
          </div>

          <div className="footer-col opacity-0 will-change-transform">
            <h4 className="text-xs font-bold uppercase tracking-widest text-white mb-8">Address</h4>
            <address className="not-italic text-xs text-white/60 space-y-4 font-light">
              <p>Prestige Falcon Towers, 19, Brunton Road, Bengaluru 560025</p>
              <p>080-69496126</p>
              <p>mohammed.maqsood@sublime.in</p>
            </address>
            <div className="flex space-x-6 mt-8 text-white/40">
              <a href="#" className="hover:text-sublime-gold hover:-translate-y-1 transition-all duration-300"><Facebook size={20} strokeWidth={1} /></a>
              <a href="#" className="hover:text-sublime-gold hover:-translate-y-1 transition-all duration-300"><Instagram size={20} strokeWidth={1} /></a>
              <a href="#" className="hover:text-sublime-gold hover:-translate-y-1 transition-all duration-300"><Twitter size={20} strokeWidth={1} /></a>
            </div>
          </div>
        </div>

        <div className="text-center text-[10px] text-white/20 uppercase tracking-[0.2em] opacity-80">
          © 2025 Sublime House of Tea | All rights reserved
        </div>
      </div>
    </footer>
  );
};

export default Footer;