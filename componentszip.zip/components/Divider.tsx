import React from 'react'
import divider from "../assests/Divider.png"

const Divider = () => {
  return (
    <div className="flex justify-center items-center">
      <img src={divider} alt="Divider" className="w-[50%] h-auto" />
    </div>
  )
}

export default Divider
